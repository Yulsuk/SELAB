package com.example.smart_waterlevelrise;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class waterQualityMonitoring extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waterquality);
    }
}
